package a1;

public class Cat {
	public void cry() {
		System.out.println("야옹");
	}
	public int age;
}
