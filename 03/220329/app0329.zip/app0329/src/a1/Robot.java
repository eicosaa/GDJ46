package a1;

public class Robot {
	public void off() {
		System.out.println("전원을 끄다");
	}
}
