
public class Robot implements IRobot {
	@Override
	public void make() {
		System.out.println("make");
	}
}
