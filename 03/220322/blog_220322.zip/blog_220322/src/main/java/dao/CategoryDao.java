package dao;

public class CategoryDao {
	public CategoryDao() { } // -생성자 메소드
}
