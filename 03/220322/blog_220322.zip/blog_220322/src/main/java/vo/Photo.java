package vo;

public class Photo {
	public int photoNo;
	public String photoName;
	public String photoOriginalName;
	public String photoType;
	public String photoPw;
	public String writer;
	public String createDate;
	public String updateDate;
}
