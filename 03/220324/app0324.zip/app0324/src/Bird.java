
public class Bird extends Animal {
	@Override
	public void cry() { // 오버라이딩
		System.out.println("짹짹");
	}
}
