
public class Computer extends Product {
	public Computer() { }
	public Computer(int price, String name, String company, int cup) {
		this.price = price;
		this.name = name;
		this.company = company;
		this.cpu = cpu;
	}
	public String company;
	public int cpu;
}
