
public class Dog extends Animal {
	@Override
	public void cry() { // 오버라이딩
		System.out.println("멍멍");
	}
}
