
public class Animal {
	public void cry() {
		System.out.println("울다");
	}
}
