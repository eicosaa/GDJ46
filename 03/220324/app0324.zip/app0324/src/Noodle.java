
public class Noodle extends Product {
	public Noodle(int price, String name, String company) {
		this.price = price;
		this.name = name;
		this.company = company;
	}
	
	public String company;
}
