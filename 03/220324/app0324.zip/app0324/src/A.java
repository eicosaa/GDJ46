
public class A {
	public String name;
}

// -복사는 유지보수가 힘들다 (원본 클래스가 수정되면 수정하기 힘들다)