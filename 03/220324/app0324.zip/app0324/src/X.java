
public class X {
	public static int m = 1;
}
