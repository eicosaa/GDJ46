// 추상화... 상속... 캡슐화... 다형성
public class Product {
	public int price;
	public String name;
}
