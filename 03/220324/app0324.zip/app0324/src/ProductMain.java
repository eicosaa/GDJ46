
public class ProductMain {

	public static void main(String[] args) {
		/*
		Noodle n = new Noodle(); // 다형성
		n.name = "신라면";
		n.company = "농심";
		
		Product p = new Noodle(); // 다형성
		p.name = "짜파게티";
		// p.company = "농심"; -접근 불가 / 접근하고 싶으면 강제형변환 필요
		// 강제 형 변환
		if(p instanceof Noodle) { // -true라면 형변환하기
			((Noodle)p).company = "농심";
			System.out.println(((Noodle)p).company);
		}
		
		Product p2 = new Vegetable(); // 다형성
		if(p2 instanceof Noodle) { // -p2가 Noodle로 형변환이 가능하면(true) 블럭 코드를 실행
			((Noodle)p2).company = "농심"; // -ClassCastException 예외 발생
		} else {
			System.out.println("p2를 Noodle로 형변환 불가");
		}
		*/		
	}

}
