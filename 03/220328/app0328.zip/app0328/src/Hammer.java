
public class Hammer extends Tool {
	public int weight;
	@Override
	public void play() {
		System.out.println("망치를 사용하다");
	}
}
