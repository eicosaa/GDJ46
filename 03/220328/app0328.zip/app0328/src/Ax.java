
public class Ax extends Tool {
	public int size;
	@Override
	public void play() {
		System.out.println("도끼를 사용하다");
	}
}
