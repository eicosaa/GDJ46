
public class Sword extends Tool {
	public int height;
	@Override
	public void play() {
		System.out.println("검을 사용하다");
	}
}
