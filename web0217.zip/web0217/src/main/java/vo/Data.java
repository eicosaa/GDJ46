package vo;

public class Data {
	public int x;
	public int y;
}
