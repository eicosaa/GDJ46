/* 주석 */
let x; // var x;
x = 10;
console.log(x);

x = 'test';
console.log(x);


alert('안녕하세요');