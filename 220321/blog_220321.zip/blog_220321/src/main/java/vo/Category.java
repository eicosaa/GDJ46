package vo;
// category 테이블 VO(도메인 객체) : VO, DTO, Domain
public class Category {
	public String categoryNAme;
	public String createDate;
	public String updateDate;
}
