package vo;

public class Pdf {
	public Pdf() {}; // -생성자 메소드
	
	public int pdfNo;
	public String pdfName;
	public String pdfOriginalName;
	public String pdfType;
	public String pdfPw;
	public String writer;
	public String createDate;
	public String updateDate;
}
