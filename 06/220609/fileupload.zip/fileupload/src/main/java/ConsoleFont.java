
public class ConsoleFont {
	public static String LCH = "\u001B[35m";
	public static String OHI = "\u001B[32m";
	public static String RESET = "\u001B[0m";
}
