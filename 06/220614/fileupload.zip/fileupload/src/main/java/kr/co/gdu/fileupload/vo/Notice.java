package kr.co.gdu.fileupload.vo;

import lombok.Data;

@Data
public class Notice {
	private int noticeId;
	private String noticeTitle;
	private String noticeContent;
	private String noticeDate;
}
