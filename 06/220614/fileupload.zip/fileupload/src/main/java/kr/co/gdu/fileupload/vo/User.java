package kr.co.gdu.fileupload.vo;

import lombok.Data;

@Data
public class User {
	private int userNo;
	private String userId;
	private String userPw;
}
