package kr.co.p0706;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P0706ApplicationTests {

	@Test
	void contextLoads() {
	}

}
