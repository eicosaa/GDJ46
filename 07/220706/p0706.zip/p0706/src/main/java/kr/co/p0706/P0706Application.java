package kr.co.p0706;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P0706Application {

	public static void main(String[] args) {
		SpringApplication.run(P0706Application.class, args);
	}

}
