package kr.co.p0705;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P0705ApplicationTests {

	@Test
	void contextLoads() {
	}

}
