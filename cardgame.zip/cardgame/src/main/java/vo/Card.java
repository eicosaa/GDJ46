package vo;

public class Card {
	public int num; // 1 ~ 13
	public String kind; // spade, diamond, heart, clover
}
