package vo;

public class Person {
	public String name;
	public int age;
	public char gender;
	public boolean married;
}
