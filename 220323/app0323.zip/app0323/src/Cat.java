
public class Cat {
	public int age;
}
