
public class Human {
	public Human() { }
	
	public String name;
	public int age;
	public void eat() {
		System.out.println("먹는다");
	}
	public void sleep() {
		System.out.println("잠잔다");
	}
	
	public String address;
}
