
public class Robot {
	public boolean onOff;
}
