package vo;
// 
public class Student {
	public int studentNo; //
	public String studentName; //
	public String studentBirth; //
	public String studentAddr;
	public String studentSchool;
	public String studentMajor;
	public String studentComplete;
	public String studentJob;
}
