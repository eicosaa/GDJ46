package commons;

import java.sql.Connection;
import java.util.List;

public class DataSource {
	public List<Connection> list;
}
