
public class System2 {
	// 4) static
	public static Out2 out2 = new Out2();
}
